"""Combine the team model with sportsbook lines and rank the bets by expected value."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from .history import Game
from .model import TeamModel
from .odds_math import devig, expected_value, kelly_fraction, fmt_american
from .odds_sources import Line
from .teams import match_team

# How much to trust our model vs. the market's no-vig price. Markets are sharp;
# a pure model that ignores them over-bets. 0.35 = 35% model, 65% market.
MODEL_WEIGHT = {"nfl": 0.35, "nba": 0.30, "nhl": 0.35, "valorant": 0.45}
MIN_GAMES = 5


@dataclass
class Play:
    sport: str
    game: str
    start: str
    bet: str
    book: str
    odds: str
    decimal: float
    model_p: float
    market_p: float | None
    blended_p: float
    push_p: float
    ev: float
    kelly_quarter: float
    other_books: str
    note: str

    def as_row(self) -> dict:
        return {
            "sport": self.sport.upper(), "game": self.game, "start": self.start[:16].replace("T", " "),
            "bet": self.bet, "best book": self.book, "odds": self.odds,
            "model %": round(100 * self.model_p, 1),
            "market %": round(100 * self.market_p, 1) if self.market_p is not None else None,
            "our %": round(100 * self.blended_p, 1),
            "EV %": round(100 * self.ev, 1), "stake (% bankroll)": round(100 * self.kelly_quarter, 2),
            "other books": self.other_books, "note": self.note,
        }


def _opposite(side: str) -> str:
    return {"home": "away", "away": "home", "over": "under", "under": "over"}[side]


def _pair_point(line: Line) -> float | None:
    if line.market == "spread":
        return -line.point
    return line.point


def market_fair_probs(lines: list[Line]) -> dict[tuple, float]:
    """No-vig probability per (event, market, side, point), averaged across books."""
    by_book = {(l.event_key, l.book, l.market, l.side, l.point): l for l in lines}
    acc: dict[tuple, list[float]] = defaultdict(list)
    for (ek, book, mk, side, pt), l in by_book.items():
        opp = by_book.get((ek, book, mk, _opposite(side), _pair_point(l)))
        if not opp:
            continue
        p, _ = devig([l.decimal, opp.decimal])
        acc[(ek, mk, side, pt)].append(p)
    return {k: sum(v) / len(v) for k, v in acc.items()}


def describe_bet(l: Line) -> str:
    team = l.home if l.side == "home" else l.away
    if l.market == "moneyline":
        return f"{team} ML"
    if l.market == "spread":
        return f"{team} {l.point:+g}"
    return f"{l.side.title()} {l.point:g}"


def recent_form(games: list[Game], team: str, n: int = 5) -> str:
    rec = [g for g in games if team in (g.home, g.away)][-n:]
    w = sum(1 for g in rec if (g.home_score > g.away_score) == (g.home == team))
    return f"{w}-{len(rec) - w}"


def find_plays(lines: list[Line], models: dict[str, TeamModel], histories: dict[str, list[Game]],
               min_ev: float = 0.0, model_weight: dict | None = None) -> tuple[list[Play], list[str]]:
    mw = {**MODEL_WEIGHT, **(model_weight or {})}
    fair = market_fair_probs(lines)
    warnings: list[str] = []

    # best price per selection (line shopping)
    groups: dict[tuple, list[Line]] = defaultdict(list)
    for l in lines:
        groups[(l.event_key, l.market, l.side, l.point)].append(l)

    plays: list[Play] = []
    unmatched = set()
    for (ek, market, side, point), ls in groups.items():
        sport, home, away = ek
        model = models.get(sport)
        if model is None:
            continue
        known = model.teams
        mh, ma = match_team(home, known), match_team(away, known)
        if not mh or not ma:
            unmatched.add(f"{sport.upper()}: {away} @ {home}")
            continue
        if sport == "valorant" and market != "moneyline":
            continue
        try:
            p_model, p_push = model.prob(market, side, point, mh, ma, neutral=(sport == "valorant"))
        except ValueError:
            continue
        p_mkt = fair.get((ek, market, side, point))
        w = mw.get(sport, 0.35)
        p = w * p_model + (1 - w) * p_mkt if p_mkt is not None else p_model
        p = min(p, 1 - p_push)

        best = max(ls, key=lambda x: x.decimal)
        ev = p * (best.decimal - 1) - (1 - p - p_push)
        notes = []
        thin = min(model.games_played.get(mh, 0), model.games_played.get(ma, 0))
        if thin < MIN_GAMES:
            notes.append(f"thin data ({thin} games)")
        if p_mkt is None:
            notes.append("no market pair - model only")
        if abs(p_model - (p_mkt or p_model)) > 0.15:
            notes.append("model and market disagree a lot - check injuries/news")
        hist = histories.get(sport, [])
        if market != "total":
            team = mh if side == "home" else ma
            notes.append(f"last5 {recent_form(hist, team)}")
        if sport != "valorant":
            eh, ea = model.expected_points(mh, ma)
            notes.append(f"proj {ma} {ea:.1f} @ {mh} {eh:.1f}")

        others = ", ".join(f"{x.book} {fmt_american(x.decimal)}" for x in sorted(ls, key=lambda x: -x.decimal)
                           if x is not best)
        plays.append(Play(
            sport, f"{away} @ {home}", best.start, describe_bet(best), best.book, fmt_american(best.decimal),
            best.decimal, p_model, p_mkt, p, p_push, ev, 0.25 * kelly_fraction(p, best.decimal),
            others, "; ".join(notes),
        ))
    if unmatched:
        warnings.append("No history matched for: " + "; ".join(sorted(unmatched)))
    plays = [pl for pl in plays if pl.ev >= min_ev]
    plays.sort(key=lambda pl: pl.ev, reverse=True)
    return plays, warnings
