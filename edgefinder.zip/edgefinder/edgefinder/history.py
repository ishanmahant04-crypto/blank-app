"""Past game results used to rate teams.

* NFL / NBA / NHL: ESPN's public scoreboard JSON (no key needed)
* Valorant: vlrggapi (unofficial vlr.gg API), map-score results

Results are cached in data/history_<sport>.csv and *merged* on every update,
so the history keeps growing even for sources that only expose recent pages.
"""
from __future__ import annotations

import csv
import os
import time
from dataclasses import dataclass, asdict
from datetime import date, datetime, timedelta, timezone

import requests

ESPN_PATHS = {"nfl": "football/nfl", "nba": "basketball/nba", "nhl": "hockey/nhl"}
DATA_DIR = os.environ.get("EDGEFINDER_DATA", os.path.join(os.path.dirname(__file__), "..", "data"))
TIMEOUT = 20


@dataclass
class Game:
    date: str        # YYYY-MM-DD
    home: str
    away: str
    home_score: float
    away_score: float
    neutral: int = 0


# --------------------------------------------------------------------------- ESPN
def fetch_espn(sport: str, days_back: int = 430, chunk_days: int = 7) -> list[Game]:
    base = f"https://site.api.espn.com/apis/site/v2/sports/{ESPN_PATHS[sport]}/scoreboard"
    end = date.today()
    start = end - timedelta(days=days_back)
    games: list[Game] = []
    cur = start
    while cur <= end:
        stop = min(cur + timedelta(days=chunk_days - 1), end)
        params = {"dates": f"{cur:%Y%m%d}-{stop:%Y%m%d}", "limit": 1000}
        try:
            r = requests.get(base, params=params, timeout=TIMEOUT)
            r.raise_for_status()
            games.extend(parse_espn(r.json()))
        except requests.RequestException as e:
            print(f"  [espn] {sport} {params['dates']} failed: {e}")
        cur = stop + timedelta(days=1)
        time.sleep(0.15)
    return games


def parse_espn(payload: dict) -> list[Game]:
    out = []
    for ev in payload.get("events", []):
        comp = (ev.get("competitions") or [{}])[0]
        if not comp.get("status", ev.get("status", {})).get("type", {}).get("completed"):
            continue
        teams = {c.get("homeAway"): c for c in comp.get("competitors", [])}
        h, a = teams.get("home"), teams.get("away")
        if not h or not a:
            continue
        try:
            out.append(Game(
                ev.get("date", "")[:10], h["team"]["displayName"], a["team"]["displayName"],
                float(h["score"]), float(a["score"]), int(bool(comp.get("neutralSite"))),
            ))
        except (KeyError, TypeError, ValueError):
            continue
    return out


# --------------------------------------------------------------------------- Valorant
def fetch_valorant(pages: int = 10) -> list[Game]:
    games: list[Game] = []
    url = "https://vlrggapi.vercel.app/match"
    for page in range(1, pages + 1):
        try:
            r = requests.get(url, params={"q": "results", "num_pages": 1, "page": page}, timeout=TIMEOUT)
            r.raise_for_status()
            segs = (r.json().get("data") or {}).get("segments") or []
        except (requests.RequestException, ValueError) as e:
            print(f"  [vlrggapi] page {page} failed: {e}")
            break
        if not segs:
            break
        games.extend(parse_vlr(segs))
        time.sleep(0.3)
    return games


def parse_vlr(segments: list[dict]) -> list[Game]:
    out = []
    for s in segments:
        try:
            s1, s2 = float(s["score1"]), float(s["score2"])
        except (KeyError, TypeError, ValueError):
            continue
        d = ""
        ts = s.get("unix_timestamp") or s.get("timestamp")
        if ts:
            try:
                d = datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%Y-%m-%d")
            except (TypeError, ValueError):
                d = str(ts)[:10]
        out.append(Game(d or date.today().isoformat(), s["team1"], s["team2"], s1, s2, 1))
    return out


# --------------------------------------------------------------------------- cache
def _path(sport: str) -> str:
    os.makedirs(DATA_DIR, exist_ok=True)
    return os.path.join(DATA_DIR, f"history_{sport}.csv")


def load(sport: str) -> list[Game]:
    p = _path(sport)
    if not os.path.exists(p):
        return []
    with open(p, newline="") as fh:
        return [Game(r["date"], r["home"], r["away"], float(r["home_score"]),
                     float(r["away_score"]), int(r.get("neutral") or 0)) for r in csv.DictReader(fh)]


def save(sport: str, games: list[Game]) -> None:
    with open(_path(sport), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(Game.__dataclass_fields__))
        w.writeheader()
        for g in games:
            w.writerow(asdict(g))


def update(sport: str) -> list[Game]:
    fresh = fetch_valorant() if sport == "valorant" else fetch_espn(sport)
    merged = {(g.date, g.home, g.away): g for g in load(sport)}
    for g in fresh:
        merged[(g.date, g.home, g.away)] = g
    games = sorted(merged.values(), key=lambda g: g.date)
    save(sport, games)
    return games
