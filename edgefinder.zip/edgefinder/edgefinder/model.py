"""Team-strength model built from past games, adjusted for opponent strength.

For every sport we fit, with recent games weighted more heavily (exponential decay):

  * margin model    : home_margin = HFA + rating[home] - rating[away]          (ridge regression)
  * scoring model   : points_for  = base + home_bonus + offense[team] - defense[opponent]

Ratings come out opponent-adjusted: beating a strong team counts for more than
beating a weak one, and scoring 30 on a great defense counts for more than 30 on a bad one.

Probabilities:
  * NFL / NBA  -> Normal distribution on margin and total (sd fitted from residuals)
  * NHL        -> independent Poisson goals per team (handles puck lines and low totals)
  * Valorant   -> Bradley-Terry (logistic) on match wins, moneyline only
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime

import numpy as np
from scipy.stats import norm, poisson

from .history import Game

SPORT_CFG = {
    #           half-life (days), ridge strength, min sd margin, min sd total
    "nfl":      dict(half_life=200, ridge=4.0, sd_m=12.5, sd_t=12.0),
    "nba":      dict(half_life=90,  ridge=6.0, sd_m=11.0, sd_t=16.0),
    "nhl":      dict(half_life=120, ridge=15.0, sd_m=2.2, sd_t=2.2),
    "valorant": dict(half_life=60,  ridge=2.0, sd_m=1.0, sd_t=1.0),
}


def _weights(games: list[Game], half_life: float, as_of: date | None = None) -> np.ndarray:
    as_of = as_of or date.today()
    w = []
    for g in games:
        try:
            d = datetime.strptime(g.date[:10], "%Y-%m-%d").date()
            age = max(0, (as_of - d).days)
        except ValueError:
            age = 0
        w.append(0.5 ** (age / half_life))
    return np.array(w)


def _ridge(X: np.ndarray, y: np.ndarray, w: np.ndarray, lam: float, free_cols: int) -> np.ndarray:
    """Weighted ridge; the first `free_cols` columns (intercepts) are not penalized."""
    W = w[:, None]
    A = X.T @ (X * W)
    pen = np.full(X.shape[1], lam)
    pen[:free_cols] = 1e-6
    A += np.diag(pen)
    return np.linalg.solve(A, X.T @ (y * w))


@dataclass
class TeamModel:
    sport: str
    teams: list[str]
    games_played: dict[str, int]
    hfa: float = 0.0
    rating: dict[str, float] = field(default_factory=dict)
    base: float = 0.0
    home_bonus: float = 0.0
    offense: dict[str, float] = field(default_factory=dict)
    defense: dict[str, float] = field(default_factory=dict)
    sd_margin: float = 1.0
    sd_total: float = 1.0
    bt: dict[str, float] = field(default_factory=dict)   # Valorant Bradley-Terry strengths

    # ------------------------------------------------------------------ fitting
    @classmethod
    def fit(cls, sport: str, games: list[Game], as_of: date | None = None) -> "TeamModel":
        cfg = SPORT_CFG[sport]
        teams = sorted({g.home for g in games} | {g.away for g in games})
        idx = {t: i for i, t in enumerate(teams)}
        played = {t: 0 for t in teams}
        for g in games:
            played[g.home] += 1
            played[g.away] += 1
        m = cls(sport, teams, played)
        if not games:
            return m
        w = _weights(games, cfg["half_life"], as_of)
        n, k = len(games), len(teams)

        if sport == "valorant":
            m._fit_bt(games, idx, w, cfg["ridge"])
            return m

        # margin model: [hfa, team ratings...]
        X = np.zeros((n, 1 + k))
        y = np.zeros(n)
        for r, g in enumerate(games):
            X[r, 0] = 0 if g.neutral else 1
            X[r, 1 + idx[g.home]] = 1
            X[r, 1 + idx[g.away]] = -1
            y[r] = g.home_score - g.away_score
        beta = _ridge(X, y, w, cfg["ridge"], free_cols=1)
        m.hfa = float(beta[0])
        m.rating = {t: float(beta[1 + idx[t]]) for t in teams}
        resid = y - X @ beta
        m.sd_margin = max(cfg["sd_m"], float(np.sqrt(np.average(resid ** 2, weights=w))))

        # scoring model: one row per team-game. [base, home, offense..., defense...]
        X2 = np.zeros((2 * n, 2 + 2 * k))
        y2 = np.zeros(2 * n)
        w2 = np.repeat(w, 2)
        for r, g in enumerate(games):
            for j, (team, opp, pts, home) in enumerate(
                    ((g.home, g.away, g.home_score, 0 if g.neutral else 1),
                     (g.away, g.home, g.away_score, 0))):
                row = 2 * r + j
                X2[row, 0] = 1
                X2[row, 1] = home
                X2[row, 2 + idx[team]] = 1
                X2[row, 2 + k + idx[opp]] = -1
                y2[row] = pts
        b2 = _ridge(X2, y2, w2, cfg["ridge"], free_cols=2)
        m.base, m.home_bonus = float(b2[0]), float(b2[1])
        m.offense = {t: float(b2[2 + idx[t]]) for t in teams}
        m.defense = {t: float(b2[2 + k + idx[t]]) for t in teams}
        tot_pred = np.array([sum(m.expected_points(g.home, g.away, bool(g.neutral))) for g in games])
        tot_res = np.array([g.home_score + g.away_score for g in games]) - tot_pred
        m.sd_total = max(cfg["sd_t"], float(np.sqrt(np.average(tot_res ** 2, weights=w))))
        return m

    def _fit_bt(self, games, idx, w, lam, iters=400, lr=0.05):
        k = len(idx)
        s = np.zeros(k)
        hi = np.array([idx[g.home] for g in games])
        ai = np.array([idx[g.away] for g in games])
        y = np.array([1.0 if g.home_score > g.away_score else 0.0 for g in games])
        for _ in range(iters):
            p = 1 / (1 + np.exp(-(s[hi] - s[ai])))
            err = (y - p) * w
            grad = np.zeros(k)
            np.add.at(grad, hi, err)
            np.add.at(grad, ai, -err)
            grad -= lam * 0.1 * s
            s += lr * grad / max(1.0, w.sum() / k)
        self.bt = {t: float(s[i]) for t, i in idx.items()}

    # ------------------------------------------------------------------ predictions
    def knows(self, team: str) -> bool:
        return team in self.games_played

    def expected_points(self, home: str, away: str, neutral: bool = False) -> tuple[float, float]:
        hb = 0 if neutral else self.home_bonus
        h = self.base + hb + self.offense.get(home, 0) - self.defense.get(away, 0)
        a = self.base + self.offense.get(away, 0) - self.defense.get(home, 0)
        return max(h, 0.1), max(a, 0.1)

    def expected_margin(self, home: str, away: str, neutral: bool = False) -> float:
        return (0 if neutral else self.hfa) + self.rating.get(home, 0) - self.rating.get(away, 0)

    def prob(self, market: str, side: str, point: float | None, home: str, away: str,
             neutral: bool = False) -> tuple[float, float]:
        """Return (P(win), P(push)) for one side of one market."""
        if self.sport == "valorant":
            if market != "moneyline":
                raise ValueError("Valorant model only prices moneylines")
            ph = 1 / (1 + math.exp(-(self.bt.get(home, 0) - self.bt.get(away, 0))))
            return (ph if side == "home" else 1 - ph), 0.0
        if self.sport == "nhl":
            return self._prob_poisson(market, side, point, home, away, neutral)
        return self._prob_normal(market, side, point, home, away, neutral)

    def _prob_normal(self, market, side, point, home, away, neutral):
        if market == "total":
            mu = sum(self.expected_points(home, away, neutral))
            return _cover(mu, self.sd_total, point, over=(side == "over"))
        mu = self.expected_margin(home, away, neutral)
        if side == "away":
            mu = -mu
        if market == "moneyline":
            p = 1 - norm.cdf(0, mu, self.sd_margin)  # ties are negligible / go to OT
            return p, 0.0
        # spread: side covers if its margin + point > 0  <=>  margin > -point
        return _cover(mu, self.sd_margin, -point, over=True)

    def _prob_poisson(self, market, side, point, home, away, neutral, cap=15):
        lh, la = self.expected_points(home, away, neutral)
        ph, pa = poisson.pmf(range(cap), lh), poisson.pmf(range(cap), la)
        grid = np.outer(ph, pa)                          # grid[h, a]
        diff = np.subtract.outer(range(cap), range(cap)) # h - a
        tot = np.add.outer(range(cap), range(cap))
        if market == "total":
            win = grid[tot > point].sum() if side == "over" else grid[tot < point].sum()
            return float(win), float(grid[tot == point].sum())
        d = diff if side == "home" else -diff
        if market == "moneyline":
            tie = grid[diff == 0].sum()
            # OT/shootout: ~coin flip tilted slightly toward the better team
            share = 0.5 + 0.1 * np.tanh((lh - la) if side == "home" else (la - lh))
            return float(grid[d > 0].sum() + tie * share), 0.0
        return float(grid[d + point > 0].sum()), float(grid[d + point == 0].sum())


def _cover(mu: float, sd: float, line: float, over: bool) -> tuple[float, float]:
    """P(X > line) for over (or X < line for under) with continuity correction for whole numbers."""
    if float(line).is_integer():
        p_hi = 1 - norm.cdf(line + 0.5, mu, sd)
        p_lo = norm.cdf(line - 0.5, mu, sd)
        push = 1 - p_hi - p_lo
        return (p_hi if over else p_lo), push
    p_hi = 1 - norm.cdf(line, mu, sd)
    return (p_hi if over else 1 - p_hi), 0.0
