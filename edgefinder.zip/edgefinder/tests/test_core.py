import random
from datetime import date, timedelta

from edgefinder.analyze import find_plays, market_fair_probs
from edgefinder.history import Game, parse_espn
from edgefinder.model import TeamModel
from edgefinder.odds_math import american_to_decimal, devig, expected_value
from edgefinder.odds_sources import Line, parse_the_odds_api
from edgefinder.teams import match_team


def fake_games(sport, n_teams=12, n=400, scale=24, spread=7, seed=1):
    rng = random.Random(seed)
    teams = [f"City{i} Team{i}" for i in range(n_teams)]
    strength = {t: rng.gauss(0, spread) for t in teams}
    games = []
    for k in range(n):
        h, a = rng.sample(teams, 2)
        d = (date.today() - timedelta(days=n - k)).isoformat()
        if sport == "nhl":
            import numpy as np
            hs = np.random.default_rng(k).poisson(max(0.5, 3 + 0.3 + strength[h] / 10))
            as_ = np.random.default_rng(k + 99999).poisson(max(0.5, 3 + strength[a] / 10))
        else:
            hs = scale + 1.5 + strength[h] / 2 - strength[a] / 2 + rng.gauss(0, 10)
            as_ = scale - strength[h] / 2 + strength[a] / 2 + rng.gauss(0, 10)
        games.append(Game(d, h, a, round(float(hs)), round(float(as_))))
    return games, strength


def test_odds_math():
    assert abs(american_to_decimal(-110) - 1.9091) < 1e-3
    assert abs(american_to_decimal(150) - 2.5) < 1e-9
    p = devig([1.9091, 1.9091])
    assert abs(p[0] - 0.5) < 1e-9
    assert abs(expected_value(0.5, 2.1) - 0.05) < 1e-9


def test_model_recovers_strength_order():
    games, strength = fake_games("nfl")
    m = TeamModel.fit("nfl", games)
    best = max(strength, key=strength.get)
    worst = min(strength, key=strength.get)
    assert m.rating[best] > m.rating[worst]
    p, _ = m.prob("moneyline", "home", None, best, worst)
    assert p > 0.7
    pw, push = m.prob("spread", "home", -3.0, best, worst)
    assert 0 < pw < 1 and push > 0
    po, _ = m.prob("total", "over", 45.5, best, worst)
    pu, _ = m.prob("total", "under", 45.5, best, worst)
    assert abs(po + pu - 1) < 1e-9


def test_nhl_poisson():
    games, _ = fake_games("nhl")
    m = TeamModel.fit("nhl", games)
    t = m.teams
    ph, _ = m.prob("moneyline", "home", None, t[0], t[1])
    pa, _ = m.prob("moneyline", "away", None, t[0], t[1])
    assert abs(ph + pa - 1) < 0.02
    p15, _ = m.prob("spread", "home", -1.5, t[0], t[1])
    assert p15 < ph


def test_valorant_bt():
    rng = random.Random(3)
    teams = ["Sentinels", "Paper Rex", "Fnatic", "G2 Esports"]
    sk = dict(zip(teams, [2, 1, 0, -1]))
    games = []
    for k in range(200):
        h, a = rng.sample(teams, 2)
        ph = 1 / (1 + 2.718 ** -(sk[h] - sk[a]))
        win = rng.random() < ph
        games.append(Game((date.today() - timedelta(days=200 - k)).isoformat(), h, a,
                          2 if win else rng.choice([0, 1]), rng.choice([0, 1]) if win else 2, 1))
    m = TeamModel.fit("valorant", games)
    assert m.bt["Sentinels"] > m.bt["G2 Esports"]


def test_end_to_end_and_line_shopping():
    games, strength = fake_games("nfl")
    m = TeamModel.fit("nfl", games)
    best = max(strength, key=strength.get)
    worst = min(strength, key=strength.get)
    lines = [
        # market thinks it's a coin flip -> our model should love the strong team
        Line("nfl", best, worst, "", "draftkings", "moneyline", "home", None, 1.91),
        Line("nfl", best, worst, "", "draftkings", "moneyline", "away", None, 1.91),
        Line("nfl", best, worst, "", "fanduel", "moneyline", "home", None, 1.95),
        Line("nfl", best, worst, "", "fanduel", "moneyline", "away", None, 1.87),
        Line("nfl", best, worst, "", "rainbet", "total", "over", 44.5, 1.90),
        Line("nfl", best, worst, "", "rainbet", "total", "under", 44.5, 1.90),
    ]
    fair = market_fair_probs(lines)
    assert len(fair) == 4
    plays, warns = find_plays(lines, {"nfl": m}, {"nfl": games}, min_ev=-1)
    top = plays[0]
    assert top.bet == f"{best} ML" and top.book == "fanduel" and top.ev > 0
    assert not warns


def test_parsers_and_names():
    events = [{"home_team": "Toronto Maple Leafs", "away_team": "Ottawa Senators", "commence_time": "x",
               "bookmakers": [{"key": "fanduel", "markets": [
                   {"key": "h2h", "outcomes": [{"name": "Toronto Maple Leafs", "price": 1.7},
                                               {"name": "Ottawa Senators", "price": 2.2}]},
                   {"key": "totals", "outcomes": [{"name": "Over", "price": 1.9, "point": 6.5},
                                                  {"name": "Under", "price": 1.9, "point": 6.5}]}]}]}]
    ls = parse_the_odds_api("nhl", events)
    assert {l.side for l in ls} == {"home", "away", "over", "under"}
    espn = {"events": [{"date": "2026-10-10T23:00Z", "competitions": [{
        "status": {"type": {"completed": True}}, "neutralSite": False,
        "competitors": [{"homeAway": "home", "score": "4", "team": {"displayName": "Toronto Maple Leafs"}},
                        {"homeAway": "away", "score": "2", "team": {"displayName": "Ottawa Senators"}}]}]}]}
    g = parse_espn(espn)[0]
    assert g.home_score == 4 and g.date == "2026-10-10"
    assert match_team("LA Clippers", ["Los Angeles Clippers", "Los Angeles Lakers"]) == "Los Angeles Clippers"
    assert match_team("Paper Rex", ["Paper Rex", "Fnatic"]) == "Paper Rex"
