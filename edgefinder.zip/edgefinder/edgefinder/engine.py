"""One entry point shared by the command line and the web app."""
from __future__ import annotations

import os
from datetime import date, datetime, timedelta

import numpy as np

from . import history
from .analyze import find_plays
from .model import TeamModel
from .odds_sources import fetch_oddspapi_valorant, fetch_the_odds_api, load_csv_lines, Line

SPORTS = ["nfl", "nba", "nhl", "valorant"]


def get_history(sport: str, refresh: bool, max_age_hours: float = 12) -> list[history.Game]:
    games = history.load(sport)
    path = history._path(sport)
    stale = not games or (datetime.now().timestamp() - os.path.getmtime(path)) > max_age_hours * 3600
    if refresh or stale:
        print(f"Updating {sport.upper()} results...")
        games = history.update(sport)
    return games


def get_lines(sports, csv_paths=(), books=None, log=print) -> list[Line]:
    lines: list[Line] = []
    for s in sports:
        try:
            if s == "valorant":
                if os.environ.get("ODDSPAPI_KEY"):
                    lines += fetch_oddspapi_valorant(books=books)
            else:
                lines += fetch_the_odds_api(s, books=books)
        except Exception as e:  # keep going with other sports / CSV
            log(f"  odds for {s.upper()} unavailable: {e}")
    for p in csv_paths:
        lines += [l for l in load_csv_lines(p) if l.sport in sports]
    return lines


def run(sports=SPORTS, csv_paths=(), min_ev=0.0, refresh=False, books=None, log=print):
    lines = get_lines(sports, csv_paths, books, log)
    sports_with_lines = sorted({l.sport for l in lines})
    hists, models = {}, {}
    for s in sports_with_lines:
        hists[s] = get_history(s, refresh)
        models[s] = TeamModel.fit(s, hists[s])
        if not hists[s]:
            log(f"  no past results for {s.upper()} - add data/history_{s}.csv")
    plays, warns = find_plays(lines, models, hists, min_ev=min_ev)
    for w in warns:
        log("  " + w)
    return plays, lines, models


def backtest(sport: str, test_days: int = 60) -> dict:
    """Fit on everything before a cutoff, then score win probabilities on games after it,
    refitting weekly. Reports log-loss vs a coin flip and how often the favorite won."""
    games = history.load(sport)
    if len(games) < 50:
        return {"error": "not enough history; run update first"}
    cutoff = date.today() - timedelta(days=test_days)
    test = [g for g in games if g.date >= cutoff.isoformat()]
    if not test:
        last = max(g.date for g in games)
        cutoff = datetime.strptime(last, "%Y-%m-%d").date() - timedelta(days=test_days)
        test = [g for g in games if g.date >= cutoff.isoformat()]
    ll, hits, n = 0.0, 0, 0
    week_start, model = None, None
    for g in sorted(test, key=lambda g: g.date):
        d = datetime.strptime(g.date, "%Y-%m-%d").date()
        if week_start is None or (d - week_start).days >= 7:
            week_start = d
            model = TeamModel.fit(sport, [x for x in games if x.date < g.date], as_of=d)
        if not (model.knows(g.home) and model.knows(g.away)) or g.home_score == g.away_score:
            continue
        p, _ = model.prob("moneyline", "home", None, g.home, g.away, neutral=bool(g.neutral))
        p = float(np.clip(p, 0.02, 0.98))
        y = 1 if g.home_score > g.away_score else 0
        ll += -(y * np.log(p) + (1 - y) * np.log(1 - p))
        hits += int((p > 0.5) == bool(y))
        n += 1
    if n == 0:
        return {"error": "no testable games"}
    return {"games": n, "log_loss": round(ll / n, 4), "coin_flip_log_loss": 0.6931,
            "favorite_hit_rate": round(hits / n, 3)}
