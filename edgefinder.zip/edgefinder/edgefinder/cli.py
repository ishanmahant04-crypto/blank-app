"""Command line:  python -m edgefinder picks | update | backtest"""
from __future__ import annotations

import argparse
import csv
import sys

from . import history
from .engine import SPORTS, backtest, run


def _print_table(rows: list[dict], cols: list[str]) -> None:
    if not rows:
        print("No plays met the EV threshold.")
        return
    widths = {c: max(len(c), *(len(str(r.get(c, ""))) for r in rows)) for c in cols}
    print("  ".join(c.ljust(widths[c]) for c in cols))
    print("  ".join("-" * widths[c] for c in cols))
    for r in rows:
        print("  ".join(str(r.get(c, "")).ljust(widths[c]) for c in cols))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="edgefinder", description="Find +EV sportsbook bets.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("picks", help="pull lines and rank bets by expected value")
    p.add_argument("--sports", default=",".join(SPORTS))
    p.add_argument("--csv", action="append", default=[], help="manual lines CSV (e.g. Rainbet)")
    p.add_argument("--min-ev", type=float, default=2.0, help="minimum EV in percent (default 2)")
    p.add_argument("--books", default="draftkings,fanduel")
    p.add_argument("--refresh", action="store_true", help="force re-download of past results")
    p.add_argument("--out", help="also write all plays to this CSV")
    p.add_argument("--top", type=int, default=25)

    u = sub.add_parser("update", help="download/refresh past results")
    u.add_argument("--sports", default=",".join(SPORTS))

    b = sub.add_parser("backtest", help="check model accuracy on recent games")
    b.add_argument("--sports", default="nfl,nba,nhl")
    b.add_argument("--days", type=int, default=60)

    a = ap.parse_args(argv)
    sports = [s.strip().lower() for s in a.sports.split(",") if s.strip()]

    if a.cmd == "update":
        for s in sports:
            g = history.update(s)
            print(f"{s.upper()}: {len(g)} games stored")
    elif a.cmd == "backtest":
        for s in sports:
            print(s.upper(), backtest(s, a.days))
    else:
        plays, lines, _ = run(sports, a.csv, min_ev=a.min_ev / 100, refresh=a.refresh,
                              books=a.books.split(","))
        print(f"\n{len(lines)} lines scanned -> {len(plays)} plays with EV >= {a.min_ev}%\n")
        rows = [pl.as_row() for pl in plays]
        _print_table(rows[: a.top], ["sport", "game", "bet", "best book", "odds", "our %",
                                     "market %", "EV %", "stake (% bankroll)", "note"])
        if a.out and rows:
            with open(a.out, "w", newline="") as fh:
                w = csv.DictWriter(fh, fieldnames=list(rows[0]))
                w.writeheader()
                w.writerows(rows)
            print(f"\nSaved {len(rows)} plays to {a.out}")


if __name__ == "__main__":
    sys.exit(main())
