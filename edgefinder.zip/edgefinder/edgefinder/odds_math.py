"""Odds conversions, vig removal, expected value and Kelly sizing."""
from __future__ import annotations


def american_to_decimal(american: float) -> float:
    american = float(american)
    if american >= 100:
        return 1 + american / 100
    if american <= -100:
        return 1 + 100 / abs(american)
    raise ValueError(f"Invalid American odds: {american}")


def decimal_to_american(decimal: float) -> int:
    if decimal >= 2:
        return round((decimal - 1) * 100)
    return round(-100 / (decimal - 1))


def implied_prob(decimal: float) -> float:
    return 1.0 / decimal


def devig(decimals: list[float]) -> list[float]:
    """Multiplicative (proportional) vig removal -> fair probabilities summing to 1."""
    raw = [1.0 / d for d in decimals]
    total = sum(raw)
    return [r / total for r in raw]


def vig_pct(decimals: list[float]) -> float:
    return sum(1.0 / d for d in decimals) - 1.0


def expected_value(prob: float, decimal: float) -> float:
    """EV per 1 unit staked."""
    return prob * (decimal - 1) - (1 - prob)


def kelly_fraction(prob: float, decimal: float) -> float:
    b = decimal - 1
    f = (b * prob - (1 - prob)) / b
    return max(0.0, f)


def fmt_american(decimal: float) -> str:
    a = decimal_to_american(decimal)
    return f"+{a}" if a > 0 else str(a)
