"""Team-name normalization so odds feeds and stats feeds line up."""
from __future__ import annotations

import difflib
import re

_STRIP = re.compile(r"[^a-z0-9 ]")


def norm(name: str) -> str:
    name = (name or "").lower().replace("&", "and")
    name = _STRIP.sub("", name)
    name = re.sub(r"\b(esports|esport|gaming|team|club|fc)\b", "", name)
    return re.sub(r"\s+", " ", name).strip()


def match_team(name: str, known: list[str], cutoff: float = 0.72) -> str | None:
    """Map a team name from an odds feed onto a name in the stats history."""
    if not known:
        return None
    n = norm(name)
    table = {norm(k): k for k in known}
    if n in table:
        return table[n]
    # nickname match: "Toronto Maple Leafs" vs "Maple Leafs", "LA Clippers" vs "Los Angeles Clippers"
    for nk, k in table.items():
        if nk and (nk.endswith(n) or n.endswith(nk)) and min(len(n), len(nk)) >= 4:
            return k
    last_n = n.split(" ")[-1]
    hits = [k for nk, k in table.items() if nk.split(" ")[-1] == last_n and len(last_n) >= 4]
    if len(hits) == 1:
        return hits[0]
    close = difflib.get_close_matches(n, list(table), n=1, cutoff=cutoff)
    return table[close[0]] if close else None
