# EdgeFinder

Pulls sportsbook lines, rates every team from its past games (adjusted for who they played),
and ranks bets by **expected value** for NFL, NBA, NHL and Valorant.

## What it does

1. **Lines** – DraftKings + FanDuel automatically (NFL/NBA/NHL via The Odds API; Valorant via OddsPapi).
   Rainbet has no public odds feed, so you paste or upload its lines as a CSV (see `rainbet_lines_example.csv`).
2. **Past games** – downloads results from ESPN (NFL/NBA/NHL) and vlr.gg (Valorant), cached in `data/` and grown over time.
3. **Opponent-adjusted model** – recent games count more. Fits:
   - a power rating per team (expected margin vs. an average team, plus home advantage),
   - separate **offense** and **defense** ratings (points scored/allowed adjusted for opponent quality),
   - NHL uses Poisson goal models (good for puck lines and 5.5/6.5 totals); Valorant uses a win-probability rating.
4. **Value check** – removes the vig from every book to get the market's fair price, blends it with the model
   (default 30–45% model / rest market, because markets are sharp), then for each bet:
   - shops for the **best price** across books,
   - computes **EV %** and a **quarter-Kelly** stake suggestion,
   - flags thin data, big model-vs-market disagreement (usually injuries/news), recent form, projected score.

## Get the free API keys (2 minutes)

| Key | Where | Needed for |
|---|---|---|
| `ODDS_API_KEY` | https://the-odds-api.com → free plan (500 requests/month) | DraftKings/FanDuel NFL/NBA/NHL lines |
| `ODDSPAPI_KEY` | https://oddspapi.io → free key | Valorant lines (optional – CSV works too) |

One "Find plays" run costs 3 requests on The Odds API (one per sport), so the free plan covers ~5 runs a day.

## Run it free as a web app (works on your phone) — Streamlit Community Cloud

1. Make a free GitHub account → **New repository** (e.g. `edgefinder`, set to **Private**) → **Upload files** →
   drag in everything from this folder (keep the `edgefinder/` folder structure) → Commit.
2. Go to https://share.streamlit.io → sign in with GitHub → **Create app** → pick your repo, branch `main`,
   main file `app.py`.
3. Click **Advanced settings → Secrets** and paste:
   ```
   ODDS_API_KEY = "your-key"
   ODDSPAPI_KEY = "your-key"
   ```
4. **Deploy**. You get a link like `https://yourname-edgefinder.streamlit.app` — bookmark it / "Add to Home Screen" on your phone.

The first run for each sport takes about a minute while it downloads a season+ of results; after that it's cached.
Free apps go to sleep after inactivity; just click "wake up".

Other free options: **Google Colab** (upload the folder, `!pip install -r requirements.txt`, `!python -m edgefinder picks`)
or **Hugging Face Spaces** (Streamlit template, same files).

## Run it on your computer

```bash
pip install -r requirements.txt
export ODDS_API_KEY=your-key          # Windows PowerShell: $env:ODDS_API_KEY="your-key"
streamlit run app.py                  # web app at http://localhost:8501
# or the command line:
python -m edgefinder picks --min-ev 2
python -m edgefinder picks --csv rainbet_lines_example.csv --sports nfl,nhl,valorant
python -m edgefinder update           # refresh past results
python -m edgefinder backtest         # how accurate the model has been recently
```

## Rainbet / manual CSV format

```
sport,home,away,book,market,side,point,odds
nfl,Kansas City Chiefs,Buffalo Bills,rainbet,spread,home,-2.5,-108
nhl,Toronto Maple Leafs,Montreal Canadiens,rainbet,moneyline,home,,-150
valorant,Sentinels,Paper Rex,rainbet,moneyline,home,,1.85
```
`odds` can be American or decimal. Enter both sides of a market so the vig can be removed.
Team names are fuzzy-matched ("LA Clippers" = "Los Angeles Clippers").

## Reading the output

| Column | Meaning |
|---|---|
| our % | Blended win probability (model + no-vig market) |
| market % | Fair probability implied by the books after removing vig |
| model % | Pure model probability from past games |
| EV % | Expected profit per $100 risked ÷ 100 at the best available price |
| stake | Quarter-Kelly suggestion as % of bankroll |

## Honest limitations

- The model knows results, not **injuries, rest, weather, or lineup changes** (big in Valorant roster swaps). When the
  note says "model and market disagree a lot", the market usually knows something — check news before betting.
- Early in a season, ratings lean on last season (decayed). Thin-data teams are flagged.
- Valorant is moneyline only; vlr.gg's API is unofficial and can break — upload `data/history_valorant.csv` if so.
- Ontario DraftKings/FanDuel prices can differ slightly from the US feed; confirm the price in the app before betting.
- Positive EV is an edge over many bets, not a guarantee on any one. Use `backtest` to see how well calibrated it is.

Gambling help (Ontario): ConnexOntario 1-866-531-2600.
