"""EdgeFinder web app (Streamlit). Run locally with:  streamlit run app.py"""
import io
import os
import tempfile

import pandas as pd
import streamlit as st

# API keys: Streamlit Cloud "Secrets" or environment variables
for k in ("ODDS_API_KEY", "ODDSPAPI_KEY"):
    try:
        if k in st.secrets and not os.environ.get(k):
            os.environ[k] = st.secrets[k]
    except Exception:
        pass

from edgefinder.engine import SPORTS, run  # noqa: E402

st.set_page_config(page_title="EdgeFinder", page_icon="📈", layout="wide")
st.title("EdgeFinder")
st.caption("Ranks DraftKings / FanDuel / Rainbet lines by expected value, using opponent-adjusted "
           "team ratings from past games blended with the no-vig market price.")

with st.sidebar:
    sports = st.multiselect("Sports", SPORTS, default=SPORTS, format_func=str.upper)
    books = st.multiselect("Books (API)", ["draftkings", "fanduel"], default=["draftkings", "fanduel"])
    min_ev = st.slider("Minimum EV %", -5.0, 15.0, 2.0, 0.5)
    refresh = st.checkbox("Force refresh past results", value=False)
    st.divider()
    st.markdown("**Rainbet / manual lines**")
    up = st.file_uploader("Lines CSV", type="csv")
    pasted = st.text_area(
        "…or paste CSV rows",
        placeholder="sport,home,away,book,market,side,point,odds\n"
                    "nfl,Kansas City Chiefs,Buffalo Bills,rainbet,spread,home,-2.5,-108",
        height=120)
    keys_ok = bool(os.environ.get("ODDS_API_KEY"))
    if not keys_ok:
        st.warning("ODDS_API_KEY not set — only manual lines will be analyzed.")
    go = st.button("Find plays", type="primary", use_container_width=True)

if go:
    csv_paths = []
    tmp = tempfile.mkdtemp()
    if up is not None:
        p = os.path.join(tmp, "upload.csv")
        open(p, "wb").write(up.getvalue())
        csv_paths.append(p)
    if pasted.strip():
        text = pasted.strip()
        if not text.lower().startswith("sport,"):
            text = "sport,home,away,book,market,side,point,odds\n" + text
        p = os.path.join(tmp, "pasted.csv")
        open(p, "w").write(text)
        csv_paths.append(p)

    logs = []
    with st.spinner("Pulling lines and past results (first run per sport takes ~1 min)…"):
        try:
            plays, lines, models = run(sports, csv_paths, min_ev=min_ev / 100, refresh=refresh,
                                       books=books or None, log=logs.append)
        except Exception as e:
            st.error(f"Run failed: {e}")
            st.stop()
    for m in logs:
        st.info(m.strip())

    st.subheader(f"{len(plays)} plays with EV ≥ {min_ev}%  ·  {len(lines)} lines scanned")
    if plays:
        df = pd.DataFrame([p.as_row() for p in plays])
        tabs = st.tabs(["All"] + sorted(df["sport"].unique()))
        cols = ["game", "bet", "best book", "odds", "our %", "market %", "model %", "EV %",
                "stake (% bankroll)", "other books", "note"]
        tabs[0].dataframe(df[["sport"] + cols], use_container_width=True, hide_index=True)
        for t, s in zip(tabs[1:], sorted(df["sport"].unique())):
            t.dataframe(df[df["sport"] == s][cols], use_container_width=True, hide_index=True)
        buf = io.StringIO()
        df.to_csv(buf, index=False)
        st.download_button("Download CSV", buf.getvalue(), "plays.csv", "text/csv")
    else:
        st.write("Nothing cleared the threshold. Lower the minimum EV or check back closer to game time.")

    with st.expander("Team power ratings"):
        for s, m in models.items():
            if s == "valorant":
                r = pd.DataFrame({"strength": m.bt, "maps/matches": m.games_played})
            else:
                r = pd.DataFrame({"rating (pts vs avg)": m.rating, "offense": m.offense,
                                  "defense": m.defense, "games": m.games_played})
            st.markdown(f"**{s.upper()}**")
            st.dataframe(r.sort_values(r.columns[0], ascending=False).round(2),
                         use_container_width=True)

st.caption("Bet only what you can afford to lose. EV is an estimate, not a guarantee. "
           "ConnexOntario: 1-866-531-2600.")
