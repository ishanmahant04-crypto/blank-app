"""Pull sportsbook lines.

Sources
-------
* The Odds API (the-odds-api.com)  -> DraftKings + FanDuel for NFL / NBA / NHL
* OddsPapi (oddspapi.io)           -> Valorant moneylines (DraftKings + others where listed)
* Manual CSV                        -> Rainbet (no public API) or any book/line you type in

Every source is normalized into `Line` objects.
"""
from __future__ import annotations

import csv
import os
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import requests

from .odds_math import american_to_decimal

ODDS_API_SPORT_KEYS = {
    "nfl": "americanfootball_nfl",
    "nba": "basketball_nba",
    "nhl": "icehockey_nhl",
}
MARKET_MAP = {"h2h": "moneyline", "spreads": "spread", "totals": "total"}
DEFAULT_BOOKS = ["draftkings", "fanduel"]
TIMEOUT = 20


@dataclass
class Line:
    sport: str
    home: str
    away: str
    start: str          # ISO time string (may be "")
    book: str
    market: str         # moneyline | spread | total
    side: str           # home | away | over | under
    point: float | None # spread for that side (e.g. -3.5) or the total (e.g. 47.5)
    decimal: float

    @property
    def event_key(self) -> tuple:
        return (self.sport, self.home, self.away)


# --------------------------------------------------------------------------- The Odds API
def fetch_the_odds_api(sport: str, api_key: str | None = None, books=None) -> list[Line]:
    api_key = api_key or os.environ.get("ODDS_API_KEY")
    if not api_key:
        raise RuntimeError("Set ODDS_API_KEY (free key at https://the-odds-api.com).")
    books = books or DEFAULT_BOOKS
    url = f"https://api.the-odds-api.com/v4/sports/{ODDS_API_SPORT_KEYS[sport]}/odds"
    params = {
        "apiKey": api_key,
        "bookmakers": ",".join(books),
        "markets": "h2h,spreads,totals",
        "oddsFormat": "decimal",
    }
    r = requests.get(url, params=params, timeout=TIMEOUT)
    r.raise_for_status()
    remaining = r.headers.get("x-requests-remaining")
    if remaining is not None:
        print(f"  [the-odds-api] {sport}: {remaining} requests left this month")
    return parse_the_odds_api(sport, r.json())


def parse_the_odds_api(sport: str, events: list[dict]) -> list[Line]:
    lines: list[Line] = []
    for ev in events:
        home, away = ev["home_team"], ev["away_team"]
        for bk in ev.get("bookmakers", []):
            for mk in bk.get("markets", []):
                market = MARKET_MAP.get(mk["key"])
                if not market:
                    continue
                for oc in mk.get("outcomes", []):
                    name = oc["name"]
                    if market == "total":
                        side = name.lower()
                    elif name == home:
                        side = "home"
                    elif name == away:
                        side = "away"
                    else:
                        continue
                    lines.append(Line(sport, home, away, ev.get("commence_time", ""), bk["key"],
                                      market, side, oc.get("point"), float(oc["price"])))
    return lines


# --------------------------------------------------------------------------- OddsPapi (Valorant)
ODDSPAPI_BASE = "https://api.oddspapi.io/v4"
VALORANT_SPORT_ID = 61
VALORANT_MATCH_WINNER = "611"


def fetch_oddspapi_valorant(api_key: str | None = None, books=None, days: int = 3) -> list[Line]:
    api_key = api_key or os.environ.get("ODDSPAPI_KEY")
    if not api_key:
        raise RuntimeError("Set ODDSPAPI_KEY for Valorant odds (https://oddspapi.io), or use a CSV.")
    wanted = set(books or DEFAULT_BOOKS + ["rainbet"])
    now = datetime.now(timezone.utc)
    fx = requests.get(f"{ODDSPAPI_BASE}/fixtures", timeout=TIMEOUT, params={
        "apiKey": api_key, "sportId": VALORANT_SPORT_ID,
        "from": now.strftime("%Y-%m-%dT%H:%M:%S"),
        "to": (now + timedelta(days=min(days, 10))).strftime("%Y-%m-%dT%H:%M:%S"),
    })
    fx.raise_for_status()
    lines: list[Line] = []
    for f in fx.json():
        if not f.get("hasOdds"):
            continue
        o = requests.get(f"{ODDSPAPI_BASE}/odds", timeout=TIMEOUT,
                         params={"apiKey": api_key, "fixtureId": f["fixtureId"]})
        if o.status_code != 200:
            continue
        home, away = f["participant1Name"], f["participant2Name"]
        for slug, book in (o.json().get("bookmakerOdds") or {}).items():
            # keep the requested books plus any sharp reference books for the consensus price
            if slug not in wanted and slug not in ("pinnacle", "polymarket"):
                continue
            outs = (book.get("markets", {}).get(VALORANT_MATCH_WINNER, {}) or {}).get("outcomes", {})
            for oid, side in (("611", "home"), ("612", "away")):
                p = ((outs.get(oid) or {}).get("players") or {}).get("0") or {}
                if p.get("active") and p.get("price"):
                    # some books report outcomes reversed; trust bookmakerOutcomeId if present
                    bo = (outs.get(oid) or {}).get("bookmakerOutcomeId")
                    s = bo if bo in ("home", "away") else side
                    lines.append(Line("valorant", home, away, f.get("startTime", ""), slug,
                                      "moneyline", s, None, float(p["price"])))
    return lines


# --------------------------------------------------------------------------- Manual CSV
def _to_decimal(raw: str) -> float:
    v = float(raw)
    return american_to_decimal(v) if abs(v) >= 100 else v


def load_csv_lines(path: str) -> list[Line]:
    """CSV columns: sport,home,away,book,market,side,point,odds[,start]
    odds may be American (-110, +145) or decimal (1.91)."""
    lines = []
    with open(path, newline="") as fh:
        for row in csv.DictReader(fh):
            if not row.get("sport") or row["sport"].startswith("#"):
                continue
            point = row.get("point", "").strip()
            lines.append(Line(
                row["sport"].strip().lower(), row["home"].strip(), row["away"].strip(),
                row.get("start", "").strip(), row["book"].strip().lower(),
                row["market"].strip().lower(), row["side"].strip().lower(),
                float(point) if point else None, _to_decimal(row["odds"]),
            ))
    return lines
