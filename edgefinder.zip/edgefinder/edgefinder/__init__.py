"""EdgeFinder - rank sportsbook lines by expected value using opponent-adjusted team models."""
__version__ = "1.0.0"
